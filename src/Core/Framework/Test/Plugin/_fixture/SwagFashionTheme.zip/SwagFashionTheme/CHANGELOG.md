# 1.0.0
- initialized SwagFashionTheme
* refactored composer.json

# 1.0.1
- added migrations
* done nothing