<?php declare(strict_types=1);

namespace SwagFashionTheme;

use Shopware\Core\Framework\Plugin;

class SwagFashionTheme extends Plugin {

}
